<!-- #banner -->
<div id="banner" class="container">
	<div class="jumbotron">
	<h1>Intuitive Design</h1>
	<p>I'm A Front-End Web Developer based in London.</p>
	</div>
</div><!-- /#banner -->