<!-- /#site-content -->
<!-- banner header.php -->
<!-- widget sidebar static content -->
	<aside id="sidebar"><!-- #sidebar content -->
	<div class="col-md-4 col-xs-12 col-sm-12 col-md-offset-1 titleService">
	
	<h3 class="servicesh3">Services</h3>
	<span class="caret pull-right"></span>
	</div>
	<div class="col-md-4 col-xs-12 col-sm-12 col-md-offset-1 column">
		<ul class="sidebar-order">
			<?php dynamic_sidebar('sidebar1'); ?>
		</ul>
	</div>
	
	</aside><!--#sidebar -->
<!-- banner header.php end -->
<!-- end of widget sidebar static content -->