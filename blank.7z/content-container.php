
<div class="container">
 <div class="row">
	<div class="col-md-7 column content">
